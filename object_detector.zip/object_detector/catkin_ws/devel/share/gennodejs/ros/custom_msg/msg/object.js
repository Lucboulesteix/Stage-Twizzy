// Auto-generated. Do not edit!

// (in-package custom_msg.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class object {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.detector_name = null;
      this.timestamp = null;
      this.num_of_objects = null;
      this.object_classes = null;
      this.detection_confidence = null;
      this.u_coords = null;
      this.v_coords = null;
      this.x_coords = null;
      this.y_coords = null;
      this.z_coords = null;
    }
    else {
      if (initObj.hasOwnProperty('detector_name')) {
        this.detector_name = initObj.detector_name
      }
      else {
        this.detector_name = '';
      }
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('num_of_objects')) {
        this.num_of_objects = initObj.num_of_objects
      }
      else {
        this.num_of_objects = 0;
      }
      if (initObj.hasOwnProperty('object_classes')) {
        this.object_classes = initObj.object_classes
      }
      else {
        this.object_classes = [];
      }
      if (initObj.hasOwnProperty('detection_confidence')) {
        this.detection_confidence = initObj.detection_confidence
      }
      else {
        this.detection_confidence = [];
      }
      if (initObj.hasOwnProperty('u_coords')) {
        this.u_coords = initObj.u_coords
      }
      else {
        this.u_coords = [];
      }
      if (initObj.hasOwnProperty('v_coords')) {
        this.v_coords = initObj.v_coords
      }
      else {
        this.v_coords = [];
      }
      if (initObj.hasOwnProperty('x_coords')) {
        this.x_coords = initObj.x_coords
      }
      else {
        this.x_coords = [];
      }
      if (initObj.hasOwnProperty('y_coords')) {
        this.y_coords = initObj.y_coords
      }
      else {
        this.y_coords = [];
      }
      if (initObj.hasOwnProperty('z_coords')) {
        this.z_coords = initObj.z_coords
      }
      else {
        this.z_coords = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type object
    // Serialize message field [detector_name]
    bufferOffset = _serializer.string(obj.detector_name, buffer, bufferOffset);
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [num_of_objects]
    bufferOffset = _serializer.int32(obj.num_of_objects, buffer, bufferOffset);
    // Serialize message field [object_classes]
    bufferOffset = _arraySerializer.string(obj.object_classes, buffer, bufferOffset, null);
    // Serialize message field [detection_confidence]
    bufferOffset = _arraySerializer.float32(obj.detection_confidence, buffer, bufferOffset, null);
    // Serialize message field [u_coords]
    bufferOffset = _arraySerializer.float32(obj.u_coords, buffer, bufferOffset, null);
    // Serialize message field [v_coords]
    bufferOffset = _arraySerializer.float32(obj.v_coords, buffer, bufferOffset, null);
    // Serialize message field [x_coords]
    bufferOffset = _arraySerializer.float32(obj.x_coords, buffer, bufferOffset, null);
    // Serialize message field [y_coords]
    bufferOffset = _arraySerializer.float32(obj.y_coords, buffer, bufferOffset, null);
    // Serialize message field [z_coords]
    bufferOffset = _arraySerializer.float32(obj.z_coords, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type object
    let len;
    let data = new object(null);
    // Deserialize message field [detector_name]
    data.detector_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [num_of_objects]
    data.num_of_objects = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [object_classes]
    data.object_classes = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [detection_confidence]
    data.detection_confidence = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [u_coords]
    data.u_coords = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [v_coords]
    data.v_coords = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [x_coords]
    data.x_coords = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [y_coords]
    data.y_coords = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [z_coords]
    data.z_coords = _arrayDeserializer.float32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.detector_name);
    object.object_classes.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 4 * object.detection_confidence.length;
    length += 4 * object.u_coords.length;
    length += 4 * object.v_coords.length;
    length += 4 * object.x_coords.length;
    length += 4 * object.y_coords.length;
    length += 4 * object.z_coords.length;
    return length + 44;
  }

  static datatype() {
    // Returns string type for a message object
    return 'custom_msg/object';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'aec6178d385719eeb3632e4a39fa778e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string detector_name
    time timestamp
    int32 num_of_objects
    string[] object_classes
    float32[] detection_confidence
    float32[] u_coords
    float32[] v_coords
    float32[] x_coords
    float32[] y_coords
    float32[] z_coords
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new object(null);
    if (msg.detector_name !== undefined) {
      resolved.detector_name = msg.detector_name;
    }
    else {
      resolved.detector_name = ''
    }

    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.num_of_objects !== undefined) {
      resolved.num_of_objects = msg.num_of_objects;
    }
    else {
      resolved.num_of_objects = 0
    }

    if (msg.object_classes !== undefined) {
      resolved.object_classes = msg.object_classes;
    }
    else {
      resolved.object_classes = []
    }

    if (msg.detection_confidence !== undefined) {
      resolved.detection_confidence = msg.detection_confidence;
    }
    else {
      resolved.detection_confidence = []
    }

    if (msg.u_coords !== undefined) {
      resolved.u_coords = msg.u_coords;
    }
    else {
      resolved.u_coords = []
    }

    if (msg.v_coords !== undefined) {
      resolved.v_coords = msg.v_coords;
    }
    else {
      resolved.v_coords = []
    }

    if (msg.x_coords !== undefined) {
      resolved.x_coords = msg.x_coords;
    }
    else {
      resolved.x_coords = []
    }

    if (msg.y_coords !== undefined) {
      resolved.y_coords = msg.y_coords;
    }
    else {
      resolved.y_coords = []
    }

    if (msg.z_coords !== undefined) {
      resolved.z_coords = msg.z_coords;
    }
    else {
      resolved.z_coords = []
    }

    return resolved;
    }
};

module.exports = object;
