
"use strict";

let object = require('./object.js');

module.exports = {
  object: object,
};
